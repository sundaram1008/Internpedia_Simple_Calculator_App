package com.forz.calculator.fragments

object Fragments {
    const val UNIT_CONVERTER_FRAGMENT = 0
    const val CALCULATOR_FRAGMENT = 1
    const val HISTORY_FRAGMENT = 2

    const val SCIENTIFIC_FUNCTION_FRAGMENT = 0
    const val DIGIT_FRAGMENT = 1


    var currentItemMainPager = CALCULATOR_FRAGMENT
}