package com.forz.calculator.converter

data class Unit(
    val id: Int,
    val unit: String,
    val result: String
)
